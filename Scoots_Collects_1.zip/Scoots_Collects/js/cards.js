/* ─── CARDS TRACKER JS ────────────────────────────────────── */

let allCards       = [];
let startingCash   = 0;
let currentFilter  = 'all';

/* ─── Format helpers ──────────────────────────────────────── */

const fmt$ = n => (n === '' || n == null)
  ? '—'
  : '$' + Number(n).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

const fmtPnl = n => {
  if (n === '' || n == null) return '—';
  const v = Number(n);
  const s = (v >= 0 ? '+' : '') + '$' + Math.abs(v).toLocaleString('en-US', { minimumFractionDigits:2, maximumFractionDigits:2 });
  return v >= 0 ? s : '-$' + Math.abs(v).toLocaleString('en-US', { minimumFractionDigits:2, maximumFractionDigits:2 });
};

const esc = s => String(s ?? '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');

/* ─── Derived values ──────────────────────────────────────── */

function deriveCard(c) {
  const pricePaid = parseFloat(c.price_paid) || 0;
  const salePrice = c.sale_price !== '' && c.sale_price != null ? parseFloat(c.sale_price) : null;

  const targetSell = c.target_sell !== '' && c.target_sell != null
    ? parseFloat(c.target_sell)
    : pricePaid * 1.20;

  const pnl = c.status === 'sold' && salePrice != null
    ? salePrice - pricePaid
    : null;

  return { ...c, _targetSell: targetSell, _pnl: pnl, _pricePaid: pricePaid, _salePrice: salePrice };
}

/* ─── Totals bar ──────────────────────────────────────────── */

function renderTotals(cards) {
  const active   = cards.filter(c => c.status === 'active');
  const sold     = cards.filter(c => c.status === 'sold');
  const invested = active.reduce((s, c) => s + c._pricePaid, 0);
  const worth    = active.reduce((s, c) => s + (parseFloat(c.current_price) || 0), 0);
  const returned = sold.reduce((s, c) => s + (c._salePrice || 0), 0);
  const spent    = cards.reduce((s, c) => s + c._pricePaid, 0);
  const cash     = startingCash - spent + returned;
  const pnl      = sold.reduce((s, c) => s + (c._pnl || 0), 0);

  document.getElementById('tot-invested').textContent     = fmt$(invested);
  document.getElementById('tot-worth').textContent        = fmt$(worth);
  document.getElementById('tot-cash').textContent         = fmt$(cash);
  document.getElementById('tot-returned').textContent     = fmt$(returned);
  document.getElementById('tot-active-count').textContent = active.length;

  const pnlEl = document.getElementById('tot-pnl');
  pnlEl.textContent = fmtPnl(pnl);
  pnlEl.className   = 'total-value ' + (pnl >= 0 ? 'positive' : 'negative');

  // Cash color
  const cashEl = document.getElementById('tot-cash');
  cashEl.className = 'total-value ' + (cash >= 0 ? '' : 'negative');
}

/* ─── Filter counts ───────────────────────────────────────── */

function updateCounts(cards) {
  document.getElementById('count-all').textContent    = cards.length;
  document.getElementById('count-active').textContent = cards.filter(c => c.status === 'active').length;
  document.getElementById('count-sold').textContent   = cards.filter(c => c.status === 'sold').length;
}

/* ─── Sport tag helper ────────────────────────────────────── */

function sportTag(sport) {
  const s = (sport || '').toUpperCase();
  const valid = ['MLB','NBA','NFL','NHL'];
  const cls = valid.includes(s) ? `tag-${s}` : '';
  return `<span class="sport-tag ${cls}">${esc(s || '—')}</span>`;
}

/* ─── Status badge ────────────────────────────────────────── */

function statusBadge(status) {
  if (status === 'active') return `<span class="badge badge-active">Active</span>`;
  if (status === 'sold')   return `<span class="badge badge-sold">Sold</span>`;
  return `<span class="badge">${esc(status)}</span>`;
}

/* ─── Image button ────────────────────────────────────────── */

function imgBtn(card) {
  const hasFront = card.image_front && card.image_front !== '';
  const hasBack  = card.image_back  && card.image_back  !== '';
  const hasAny   = hasFront || hasBack;
  const cls      = hasAny ? 'img-btn has-images' : 'img-btn';
  const label    = hasAny ? '🖼 View' : '📷 No Images';
  return `<button class="${cls}" data-id="${card.id}">${label}</button>`;
}

/* ─── Render table row ────────────────────────────────────── */

function renderRow(card) {
  const pp   = fmt$(card._pricePaid);
  const ts   = fmt$(card._targetSell);
  const cp   = card.current_price !== '' && card.current_price != null ? fmt$(card.current_price) : '—';
  const sp   = card._salePrice != null ? fmt$(card._salePrice) : '—';
  const pnl  = card._pnl != null ? fmtPnl(card._pnl) : '—';
  const pnlClass = card._pnl != null ? (card._pnl >= 0 ? 'cell-positive' : 'cell-negative') : 'cell-muted';
  const rowClass = card.status === 'sold' ? 'row-sold' : '';

  return `
    <tr class="${rowClass}" data-status="${card.status}">
      <td class="sticky-col">${esc(card.name)}</td>
      <td>${sportTag(card.sport)}</td>
      <td>${esc(card.set || '—')}</td>
      <td>${esc(card.condition || '—')}</td>
      <td class="mono">${pp}</td>
      <td class="mono cell-accent">${ts}</td>
      <td class="mono">${cp}</td>
      <td><div class="thesis-cell" title="${esc(card.thesis)}">${esc(card.thesis || '—')}</div></td>
      <td class="cell-muted">${esc(card.notes || '—')}</td>
      <td class="mono cell-muted">${esc(card.sale_date || '—')}</td>
      <td class="mono">${sp}</td>
      <td>${esc(card.sale_site || '—')}</td>
      <td class="mono ${pnlClass}">${pnl}</td>
      <td>${statusBadge(card.status)}</td>
      <td>${imgBtn(card)}</td>
    </tr>`;
}

/* ─── Render table ────────────────────────────────────────── */

function renderTable(filter) {
  const filtered = filter === 'all'
    ? allCards
    : allCards.filter(c => c.status === filter);

  const tbody = document.getElementById('cards-tbody');

  if (filtered.length === 0) {
    tbody.innerHTML = `
      <tr>
        <td colspan="15">
          <div class="empty-state">
            <div class="empty-icon">🗂</div>
            <div class="empty-text">No ${filter === 'all' ? '' : filter + ' '}cards found.</div>
          </div>
        </td>
      </tr>`;
    return;
  }

  tbody.innerHTML = filtered.map(renderRow).join('');
  attachImageBtnListeners();
}

/* ─── Image modal ─────────────────────────────────────────── */

function openModal(cardId) {
  const card    = allCards.find(c => c.id === cardId);
  if (!card) return;

  document.getElementById('modal-card-name').textContent = card.name;
  document.getElementById('modal-card-set').textContent  = `${card.set || ''} · ${card.condition || ''}`;

  const frontWrap = document.getElementById('modal-front-wrap');
  const backWrap  = document.getElementById('modal-back-wrap');

  frontWrap.innerHTML = card.image_front
    ? `<img class="modal-img" src="${esc(card.image_front)}" alt="${esc(card.name)} front" />`
    : `<div class="modal-placeholder">
         <div class="modal-placeholder-icon">📷</div>
         <div>No image added yet.<br/>Add path to <code>image_front</code> in cards.json</div>
       </div>`;

  backWrap.innerHTML = card.image_back
    ? `<img class="modal-img" src="${esc(card.image_back)}" alt="${esc(card.name)} back" />`
    : `<div class="modal-placeholder">
         <div class="modal-placeholder-icon">📷</div>
         <div>No image added yet.<br/>Add path to <code>image_back</code> in cards.json</div>
       </div>`;

  document.getElementById('modal-overlay').classList.add('open');
}

function closeModal() {
  document.getElementById('modal-overlay').classList.remove('open');
}

function attachImageBtnListeners() {
  document.querySelectorAll('.img-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = parseInt(btn.dataset.id, 10);
      openModal(id);
    });
  });
}

document.getElementById('modal-close').addEventListener('click', closeModal);
document.getElementById('modal-overlay').addEventListener('click', e => {
  if (e.target === e.currentTarget) closeModal();
});
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') closeModal();
});

/* ─── Filter buttons ──────────────────────────────────────── */

document.querySelectorAll('.filter-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    currentFilter = btn.dataset.filter;
    renderTable(currentFilter);
  });
});

/* ─── Load data ───────────────────────────────────────────── */

async function loadCards() {
  let data;
  try {
    const res = await fetch('data/cards.json');
    data = await res.json();
  } catch(e) {
    document.getElementById('cards-tbody').innerHTML = `
      <tr>
        <td colspan="15" style="text-align:center;padding:3rem;color:var(--negative);">
          ⚠️ Could not load cards.json.<br/>
          <span style="font-size:0.75rem;color:var(--text-muted);">
            Make sure you are viewing via a local server or GitHub Pages, not directly from the file system.
          </span>
        </td>
      </tr>`;
    return;
  }

  startingCash = parseFloat(data.starting_cash) || 0;
  allCards     = (data.cards || []).map(deriveCard);

  updateCounts(allCards);
  renderTotals(allCards);
  renderTable(currentFilter);
}

loadCards();
