/* ─── LANDING PAGE JS ─────────────────────────────────────── */

const SPORTS = [
  { key: 'MLB', cls: 'mlb', api: 'baseball/mlb',      emoji: '⚾' },
  { key: 'NBA', cls: 'nba', api: 'basketball/nba',    emoji: '🏀' },
  { key: 'NFL', cls: 'nfl', api: 'football/nfl',      emoji: '🏈' },
  { key: 'NHL', cls: 'nhl', api: 'hockey/nhl',        emoji: '🏒' },
];

/* ─── Datetime ────────────────────────────────────────────── */

function updateDatetime() {
  const now = new Date();
  const days   = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
  const months = ['January','February','March','April','May','June','July','August','September','October','November','December'];
  const day   = days[now.getDay()];
  const date  = now.getDate();
  const month = months[now.getMonth()];
  const year  = now.getFullYear();
  const hours = String(now.getHours()).padStart(2,'0');
  const mins  = String(now.getMinutes()).padStart(2,'0');
  const secs  = String(now.getSeconds()).padStart(2,'0');
  document.getElementById('live-datetime').textContent =
    `${day}, ${month} ${date}, ${year}  ·  ${hours}:${mins}:${secs}`;
}

updateDatetime();
setInterval(updateDatetime, 1000);

/* ─── Format helpers ──────────────────────────────────────── */

const fmt$ = n => n == null || n === '' ? '$0.00'
  : '$' + Number(n).toLocaleString('en-US', { minimumFractionDigits:2, maximumFractionDigits:2 });

/* ─── Load cards & render dashboard ──────────────────────── */

async function loadPortfolio() {
  let data;
  try {
    const res = await fetch('data/cards.json');
    data = await res.json();
  } catch(e) {
    console.warn('Could not load cards.json. Make sure you are running from a server.', e);
    return;
  }

  const { starting_cash = 0, cards = [] } = data;

  const active = cards.filter(c => c.status === 'active');
  const sold   = cards.filter(c => c.status === 'sold');

  const inventoryWorth = active.reduce((s, c) => s + (parseFloat(c.current_price) || 0), 0);
  const totalSpent     = cards.reduce((s, c) => s + (parseFloat(c.price_paid) || 0), 0);
  const totalReturned  = sold.reduce((s, c) => s + (parseFloat(c.sale_price) || 0), 0);
  const cashOnHand     = starting_cash - totalSpent + totalReturned;
  const totalPnl       = sold.reduce((s, c) => {
    const pp = parseFloat(c.price_paid) || 0;
    const sp = parseFloat(c.sale_price) || 0;
    return s + (sp - pp);
  }, 0);

  // Stat cards
  document.getElementById('stat-inventory').textContent = fmt$(inventoryWorth);
  document.getElementById('stat-cash').textContent      = fmt$(cashOnHand);
  document.getElementById('stat-card-count').textContent = `${active.length} active card${active.length !== 1 ? 's' : ''}`;

  const pnlEl = document.getElementById('stat-pnl');
  pnlEl.textContent = (totalPnl >= 0 ? '+' : '') + fmt$(totalPnl);
  pnlEl.className   = 'stat-value ' + (totalPnl >= 0 ? 'positive' : 'negative');

  document.getElementById('stat-total').textContent = cards.length;
  document.getElementById('stat-sold-count').textContent = `${sold.length} card${sold.length !== 1 ? 's' : ''} sold`;

  // Sport breakdown (based on active cards' current_price)
  renderSportBreakdown(active);
}

function renderSportBreakdown(active) {
  const totals = { MLB: 0, NBA: 0, NFL: 0, NHL: 0 };
  const counts = { MLB: 0, NBA: 0, NFL: 0, NHL: 0 };

  active.forEach(c => {
    const sport = (c.sport || '').toUpperCase();
    if (totals[sport] !== undefined) {
      totals[sport] += parseFloat(c.current_price) || 0;
      counts[sport]++;
    }
  });

  const grandTotal = Object.values(totals).reduce((s, v) => s + v, 0);
  const grid = document.getElementById('sport-grid');
  grid.innerHTML = '';

  SPORTS.forEach(s => {
    const amount = totals[s.key];
    const pct    = grandTotal > 0 ? (amount / grandTotal) * 100 : 0;
    const count  = counts[s.key];

    const el = document.createElement('div');
    el.className = `sport-item ${s.cls}`;
    el.innerHTML = `
      <div class="sport-name">${s.emoji} ${s.key}</div>
      <div class="sport-amount">${fmt$(amount)}</div>
      <div class="sport-bar-track">
        <div class="sport-bar-fill" data-pct="${pct.toFixed(1)}" style="width:0%"></div>
      </div>
      <div class="sport-footer">
        <span class="sport-pct">${pct.toFixed(1)}%</span>
        <span class="sport-count">${count} card${count !== 1 ? 's' : ''}</span>
      </div>
    `;
    grid.appendChild(el);
  });

  // Animate bars after DOM insert
  requestAnimationFrame(() => {
    requestAnimationFrame(() => {
      document.querySelectorAll('.sport-bar-fill').forEach(bar => {
        bar.style.width = bar.dataset.pct + '%';
      });
    });
  });
}

/* ─── ESPN Scores ─────────────────────────────────────────── */

async function fetchScores(sport) {
  const url = `https://site.api.espn.com/apis/site/v2/sports/${sport.api}/scoreboard`;
  try {
    const res  = await fetch(url);
    const data = await res.json();
    return data.events || [];
  } catch(e) {
    return null;
  }
}

function parseEvent(event) {
  const comp        = event.competitions?.[0];
  const competitors = comp?.competitors || [];
  const away        = competitors.find(c => c.homeAway === 'away') || competitors[0];
  const home        = competitors.find(c => c.homeAway === 'home') || competitors[1];
  const status      = event.status?.type;

  const awayAbbr  = away?.team?.abbreviation  || '—';
  const homeAbbr  = home?.team?.abbreviation  || '—';
  const awayScore = away?.score ?? '';
  const homeScore = home?.score ?? '';

  const state       = status?.state || '';
  const description = status?.shortDetail || status?.description || '';
  const isLive      = state === 'in';
  const isFinal     = state === 'post';
  const isPre       = state === 'pre';

  return { awayAbbr, homeAbbr, awayScore, homeScore, isLive, isFinal, isPre, description };
}

function buildScoreRows(events) {
  if (!events || events.length === 0) {
    return `<div class="scores-loading">No games scheduled today</div>`;
  }
  return events.slice(0, 8).map(ev => {
    const { awayAbbr, homeAbbr, awayScore, homeScore, isLive, isFinal, isPre, description } = parseEvent(ev);
    const teamsHtml  = `<span class="score-teams">${awayAbbr} <span style="color:var(--text-muted)">@</span> ${homeAbbr}</span>`;
    let resultHtml   = '';
    let statusHtml   = '';

    if (isPre) {
      resultHtml = `<span class="score-result" style="color:var(--text-muted)">—</span>`;
      statusHtml = `<span class="score-status">${description}</span>`;
    } else if (isLive) {
      resultHtml = `<span class="score-result">${awayScore} – ${homeScore}</span>`;
      statusHtml = `<span class="live-dot">${description}</span>`;
    } else {
      resultHtml = `<span class="score-result">${awayScore} – ${homeScore}</span>`;
      statusHtml = `<span class="score-status">${description}</span>`;
    }

    return `
      <div class="score-row">
        ${teamsHtml}
        <div class="score-details">${resultHtml}${statusHtml}</div>
      </div>`;
  }).join('');
}

async function loadAllScores() {
  SPORTS.forEach(async sport => {
    const el     = document.getElementById(`scores-${sport.cls}`);
    const events = await fetchScores(sport);
    el.innerHTML = buildScoreRows(events);
  });
}

/* ─── Init ────────────────────────────────────────────────── */

loadPortfolio();
loadAllScores();

// Refresh scores every 60 seconds
setInterval(loadAllScores, 60000);
